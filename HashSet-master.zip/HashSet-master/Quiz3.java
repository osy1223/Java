//4.�Ʒ��� ȣ��ǵ��� BoxFactory Ŭ������ ����ÿ�.
//Box<String> sBox = BoxFactory.<String>makeBox("Sweet");
//Box<Double> dBox = BoxFactory.<Double>makeBox(7.59);
class Box<T> {
	protected T ob;
	public void set(T o) {ob =o;}
	public T get() {return ob;}
}

class BoxFactory{
	public static <T> Box<T> makeBox(T o) {
		Box<T> box = new Box<T>();
		box.set(o);
		return box;
	}
}

class Quiz3{
	public static void main(String[] args) {
		Box<String> sBox = BoxFactory.<String>makeBox("Sweet");
		Box<Double> dBox = BoxFactory.<Double>makeBox(7.59);
		
		System.out.println(sBox.get());
		System.out.println(dBox.get());
	}
}