import javax.swing.JOptionPane;

class ThreadEx2 {
	public static void main(String[] args) {
		ThreadEx2_1 th1 = new ThreadEx2_1();
		th1.start();
		
		String input = JOptionPane.showInputDialog("�ƹ� ���̳� �Է��ϼ���");
		System.out.println("�Է��Ͻ� ���� "+input+"�Դϴ�");
	}
}

class ThreadEx2_1 extends Thread{
	public void run() {
		for(int i=0; i>0; i--) {
			System.out.println(i);
			try{sleep(1000);} catch(Exception e) {}
		}
	}
}