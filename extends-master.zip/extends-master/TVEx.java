
public class TVEx {
	public static void main(String[] args) {
		ColorTV myTV = new ColorTV(32, 1024);
		myTV.pirntProperty();
	}
}
