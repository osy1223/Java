class Circle extends Shape{
	private int radius;
	
	Circle(int radius){
		this.radius=radius;
	}
	
	int getArea() {
		return radius*radius*(int)Math.PI;
	}
}

class Triangle extends Shape{
	private int width;
	private int height;

	Triangle(int width, int height){
		this.width = width;
		this.height = height;
	}
	int getArea() {
		return width*height;
	}
}

class Rectangle extends Shape{
	private int width;
	private int height;

	Rectangle(int width, int height){
		this.width = width;
		this.height = height;
	}
	int getArea() {
		return width*height;
	}
}

class Shape{
	int getArea() {
		return 0;
	}
}

public class Area {
	public static void main(String[] args) {
	
//		Circle circle = new Circle(10);
//		Triangle triangle = new Triangle(20,10);
//		Rectangle rectangle = new Rectangle(20,10);		
//		
//		System.out.println(circle.getArea()+triangle.getArea()+rectangle.getArea());
//		
		Shape[] shapes = new Shape[3];
		
		shapes[0] = new Circle(10);
		shapes[1] = new Triangle(20,10);
		shapes[2] = new Rectangle(10,20);
		
		int totalArea = 0;
		for(Shape shape : shapes) {
			totalArea = totalArea + shape.getArea();
		}
		System.out.println(totalArea);
	}
}
