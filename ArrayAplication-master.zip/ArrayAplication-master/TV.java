class TV {
	private int size;
	public TV(int size) {this.size = size;}
	protected int getSize() {return size;}		
}
	
class ColorTV extends TV{
	int inch; 
	
	public ColorTV(int size, int inch) {
		super(size);
		this.inch = inch;
	}
	
	public int getInch() {
		return inch;
	}

	public void printProperty() {
		System.out.println(super.getSize()+"��ġ�� "+this.getInch());
		
	}
}