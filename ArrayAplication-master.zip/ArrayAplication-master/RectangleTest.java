import java.util.Scanner;

class Rectangle2{
	private int width, height;
	
	Rectangle2(int width, int height){
		this.width = width;
		this.height = height;
	}
	public int getArea() {
		return width*height;
	}
	
	public static Rectangle2 getMaxRec(Rectangle2[] recArr) {
		Rectangle2 maxRec = recArr[0];
		
		for(Rectangle2 rec: recArr) {
			if(maxRec.getArea() < rec.getArea()) {
				maxRec = rec;
			}
		}
//		for(int i =0; i<recArr.length; i++) {
//			if(maxRec.getArea() < recArr[i].getArea()) {
//				maxRec = recArr[i];
//			}
//		}
		return maxRec;
	}
}

public class RectangleTest {

	public static void main(String[] args) {
		
		Rectangle2[] recArr = new Rectangle2[3];
		Scanner scanner = null;
		
		for(int i=0; i<3; i++) {
			scanner = new Scanner(System.in);
			int width = scanner.nextInt();
			int height = scanner.nextInt();
			recArr[i] = new Rectangle2(width, height);
		}
		
		Rectangle2 maxRec = Rectangle2.getMaxRec(recArr);
		System.out.println(maxRec.getArea());
	}
}
