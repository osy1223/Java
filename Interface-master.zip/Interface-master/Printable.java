interface Printable{
	public void print(String a);	
}

class SPrinterDriver implements Printable {
	@Override
	public void print(String a) {
		System.out.println("From Samsung printer");
		System.out.println(a);
	}
}

class LPrinterDriver implements Printable {
	@Override
	public void print(String a) {
	System.out.println("From LG printer");
	System.out.println(a);
	}
}


