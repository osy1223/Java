
public class PersonTest {

	public static void main(String[] args) {
		
		Person person1 = new Person("jeong-pro", 27);
		Person person2 = new Person("jeong-pro", 27);
				
		//person1.equals(person2)		
		//person2.equals(person1)
		
		System.out.println(person1.equals(person2));
		
		}		
	
}
