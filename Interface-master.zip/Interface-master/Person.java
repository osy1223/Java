
class Person {
	private String name;
	private int age;
	
	public Person(String name, int age){
		this.name = name;
		this.age = age;		
	}
	
	@Override //�Լ����׸� ���
	public boolean equals(Object obj) {
		if((this.name == ((Person)obj).name) &
		(this.age == ((Person)obj).age))
			return true;
		else
			return false;
		
		
			
	}
}
